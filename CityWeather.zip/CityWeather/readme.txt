Steps to Execute--
1. Open the solution "CityWeather.sln"
2. Run the solution 
3. open in browser
4. upload excel file with cityid and Name attached, please use this.
5.click upload to get report
